// [main.c]
// this template is provided for the 2D shooter game.

#include <stdio.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#include <math.h>

// If defined, logs will be shown on console and written to file.
// If commented out, logs will not be shown nor be saved.
#define LOG_ENABLED

/* Constants. */

// Frame rate (frame per second)
const int FPS = 60;
// Display (screen) width.
const int SCREEN_W = 800;
// Display (screen) height.
const int SCREEN_H = 600;
// At most 10 audios can be played at a time.
const int RESERVE_SAMPLES = 10;

int highscore = -1;
bool new_high = false;
// Same as:
// const int SCENE_MENU = 1;
// const int SCENE_START = 2;
enum {
    SCENE_MENU = 1,
    SCENE_START = 2,
    // [HACKATHON 3-7]
    // DONE: Declare a new scene id.
    SCENE_SETTINGS = 3,
    SCENE_WIN = 4,
    SCENE_LOSE = 5
};


int score = 0;
#define LIVES 3
#define MAX_HP 100
int lives = LIVES;
double last_hit;
int hp = MAX_HP;

#define INVINCIBLE_TIME 1.5
#define ENEMY_HIT_SCORE 30;
#define ENEMY_KILL_SCORE 70;


ALLEGRO_COLOR plane_hit_tint;

/* Input states */

// The active scene id.
int active_scene;
// Keyboard state, whether the key is down or not.
bool key_state[ALLEGRO_KEY_MAX];
// Mouse state, whether the key is down or not.
// 1 is for left, 2 is for right, 3 is for middle.
bool *mouse_state;
// Mouse position.
int mouse_x, mouse_y;
// TODO: More variables to store input states such as joysticks, ...

/* Variables for allegro basic routines. */

ALLEGRO_DISPLAY* game_display;
ALLEGRO_EVENT_QUEUE* game_event_queue;
ALLEGRO_TIMER* game_update_timer;

/* Shared resources*/

ALLEGRO_FONT* font_pirulen_32;
ALLEGRO_FONT* font_pirulen_small;
ALLEGRO_FONT* font_pirulen_24;
// TODO: More shared resources or data that needed to be accessed
// across different scenes.

/* Menu Scene resources*/
ALLEGRO_BITMAP* main_img_background;
// [HACKATHON 3-1]
// DONE: Declare 2 variables for storing settings images.
// Uncomment and fill in the code below.
ALLEGRO_BITMAP* img_settings;
ALLEGRO_BITMAP* img_settings2;
ALLEGRO_SAMPLE* main_bgm;
ALLEGRO_SAMPLE_ID main_bgm_id;

/* Start Scene resources*/
ALLEGRO_BITMAP* start_img_background;
ALLEGRO_BITMAP* start_img_plane;
ALLEGRO_BITMAP* start_img_enemy;
ALLEGRO_SAMPLE* start_bgm;
ALLEGRO_SAMPLE_ID start_bgm_id;
// [HACKATHON 2-1]
// DONE: Declare a variable to store your bullet's image.
// Uncomment and fill in the code below.
ALLEGRO_BITMAP* img_bullet;
ALLEGRO_BITMAP* img_tank;
ALLEGRO_BITMAP* img_heart_red;
ALLEGRO_BITMAP* img_heart_gray;

ALLEGRO_BITMAP* player_imgs[4];
int player_style = 0;
int menu_selection = 0;

ALLEGRO_COLOR enemy_bullet_tint;
ALLEGRO_COLOR enemy_lives_tint[2];

ALLEGRO_SAMPLE* win_me;
ALLEGRO_SAMPLE* lose_me;
ALLEGRO_SAMPLE* menu_bgm;
ALLEGRO_SAMPLE_ID menu_bgm_id;


ALLEGRO_SAMPLE* destroy;
ALLEGRO_SAMPLE* fire;
ALLEGRO_SAMPLE* hit;
ALLEGRO_SAMPLE* lose_live;
ALLEGRO_SAMPLE* minus_hp;
ALLEGRO_SAMPLE* select_enter;



typedef struct {
    // The center coordinate of the image.
    float x, y;
    // The width and height of the object.
    float w, h;
    // The velocity in x, y axes.
    float vx, vy;
    // Should we draw this object on the screen.
    bool hidden;
    // The pointer to the object’s image.
    ALLEGRO_BITMAP* img;
    // Rotation in radian
    double rotation;
    float orgx;
    ALLEGRO_COLOR *tint;
} MovableObject;

typedef struct {
    float x, y;
    float offset;
    float oscspeed;
    float amplitudex;
    float amplitudey;
} EnemyGroup;

void draw_movable_object(MovableObject obj);
#define MAX_ENEMY_GROUP 4
#define ENEMY_PER_GROUP 4
#define HOMING_ENEMIES 5
#define MAX_ENEMY  (MAX_ENEMY_GROUP * ENEMY_PER_GROUP + HOMING_ENEMIES)

#define ENEMY_LIFE 3
// [HACKATHON 2-2]
// DONE: Declare the max bullet count that will show on screen.
// You can try max 4 bullets here and see if you needed more.
// Uncomment and fill in the code below.
#define MAX_BULLET 5
MovableObject plane;
MovableObject enemies[MAX_ENEMY];
int enemylifes[MAX_ENEMY];
MovableObject homing_bullets[HOMING_ENEMIES];
double homing_last_shoot[HOMING_ENEMIES];
EnemyGroup enemygroups[MAX_ENEMY_GROUP];
// [HACKATHON 2-3]
// DONE: Declare an array to store bullets with size of max bullet count.
// Uncomment and fill in the code below.
MovableObject bullets[MAX_BULLET];
// [HACKATHON 2-4]
// DONE: Set up bullet shooting cool-down variables.
// 1) Declare your shooting cool-down time as constant. (0.2f will be nice)
// 2) Declare your last shoot timestamp.
// Uncomment and fill in the code below.
const float MAX_COOLDOWN = 0.2f;
double last_shoot_timestamp;

/* Declare function prototypes. */

// Initialize allegro5 library
void allegro5_init(void);
// Initialize variables and resources.
// Allows the game to perform any initialization it needs before
// starting to run.
void game_init(void);
// Process events inside the event queue using an infinity loop.
void game_start_event_loop(void);
// Run game logic such as updating the world, checking for collision,
// switching scenes and so on.
// This is called when the game should update its logic.
void game_update(void);
// Draw to display.
// This is called when the game should draw itself.
void game_draw(void);
// Release resources.
// Free the pointers we allocated.
void game_destroy(void);
// Function to change from one scene to another.
void game_change_scene(int next_scene);
// Load resized bitmap and check if failed.
ALLEGRO_BITMAP *load_bitmap_resized(const char *filename, int w, int h);
// [HACKATHON 3-2]
// DONE: Declare a function.
// Determines whether the point (px, py) is in rect (x, y, w, h).
// Uncomment the code below.
bool pnt_in_rect(int px, int py, int x, int y, int w, int h);

// Pixelwise collide detection
bool pixel_collide(MovableObject *a, MovableObject *b);


/* Event callbacks. */
void on_key_down(int keycode);
void on_mouse_down(int btn, int x, int y);

/* Declare function prototypes for debugging. */

// Display error message and exit the program, used like 'printf'.
// Write formatted output to stdout and file from the format string.
// If the program crashes unexpectedly, you can inspect "log.txt" for
// further information.
void game_abort(const char* format, ...);
// Log events for later debugging, used like 'printf'.
// Write formatted output to stdout and file from the format string.
// You can inspect "log.txt" for logs in the last run.
void game_log(const char* format, ...);
// Log using va_list.
void game_vlog(const char* format, va_list arg);

int main(int argc, char** argv) {
    // Set random seed for better random outcome.
    srand(time(NULL));
    allegro5_init();
    game_log("Allegro5 initialized");
    game_log("Game begin");
    // Initialize game variables.
    game_init();
    game_log("Game initialized");
    // Draw the first frame.
    game_draw();
    game_log("Game start event loop");
    // This call blocks until the game is finished.
    game_start_event_loop();
    game_log("Game end");
    game_destroy();
    return 0;
}

void allegro5_init(void) {
    if (!al_init())
        game_abort("failed to initialize allegro");

    // Initialize add-ons.
    if (!al_init_primitives_addon())
        game_abort("failed to initialize primitives add-on");
    if (!al_init_font_addon())
        game_abort("failed to initialize font add-on");
    if (!al_init_ttf_addon())
        game_abort("failed to initialize ttf add-on");
    if (!al_init_image_addon())
        game_abort("failed to initialize image add-on");
    if (!al_install_audio())
        game_abort("failed to initialize audio add-on");
    if (!al_init_acodec_addon())
        game_abort("failed to initialize audio codec add-on");
    if (!al_reserve_samples(RESERVE_SAMPLES))
        game_abort("failed to reserve samples");
    if (!al_install_keyboard())
        game_abort("failed to install keyboard");
    if (!al_install_mouse())
        game_abort("failed to install mouse");
    // TODO: Initialize other addons such as video, ...

    // Setup game display.
    game_display = al_create_display(SCREEN_W, SCREEN_H);
    if (!game_display)
        game_abort("failed to create display");
    al_set_window_title(game_display, "I2P(I)_2020 Final Project 109062302");

    // Setup update timer.
    game_update_timer = al_create_timer(1.0f / FPS);
    if (!game_update_timer)
        game_abort("failed to create timer");

    // Setup event queue.
    game_event_queue = al_create_event_queue();
    if (!game_event_queue)
        game_abort("failed to create event queue");

    // Malloc mouse buttons state according to button counts.
    const unsigned m_buttons = al_get_mouse_num_buttons();
    game_log("There are total %u supported mouse buttons", m_buttons);
    // mouse_state[0] will not be used.
    mouse_state = malloc((m_buttons + 1) * sizeof(bool));
    memset(mouse_state, false, (m_buttons + 1) * sizeof(bool));

    // Register display, timer, keyboard, mouse events to the event queue.
    al_register_event_source(game_event_queue, al_get_display_event_source(game_display));
    al_register_event_source(game_event_queue, al_get_timer_event_source(game_update_timer));
    al_register_event_source(game_event_queue, al_get_keyboard_event_source());
    al_register_event_source(game_event_queue, al_get_mouse_event_source());
    // TODO: Register other event sources such as timer, video, ...

    // Start the timer to update and draw the game.
    al_start_timer(game_update_timer);
}

void game_init(void) {
    /* Shared resources*/
    font_pirulen_32 = al_load_font("pirulen.ttf", 32, 0);
    if (!font_pirulen_32)
        game_abort("failed to load font: pirulen.ttf with size 32");

    font_pirulen_24 = al_load_font("pirulen.ttf", 24, 0);
    if (!font_pirulen_24)
        game_abort("failed to load font: pirulen.ttf with size 24");

    font_pirulen_small = al_load_font("pirulen.ttf", 15, 0);


    /* Menu Scene resources*/

    main_img_background = load_bitmap_resized("main-bg.jpg", SCREEN_W, SCREEN_H);

    main_bgm = al_load_sample("S31-Night Prowler.ogg");
    if (!main_bgm)
        game_abort("failed to load audio: S31-Night Prowler.ogg");

    menu_bgm = al_load_sample("menu-bgm-split.wav");
    win_me = al_load_sample("me_game_clear.wav");
    lose_me = al_load_sample("me_game_gameover.wav");

    destroy = al_load_sample("destroy.wav");;
    fire = al_load_sample("fire.wav");;
    hit = al_load_sample("hit.wav");;
    lose_live = al_load_sample("lose_live.wav");;
    minus_hp = al_load_sample("minus_hp.wav");;
    select_enter = al_load_sample("select.wav");;


    // [HACKATHON 3-4]
    // DONE: Load settings images.
    // Don't forget to check their return values.
    // Uncomment and fill in the code below.
    img_settings = al_load_bitmap("settings.png");
    if (!img_settings)
        game_abort("failed to load image: settings.png");
    img_settings2 = al_load_bitmap("settings2.png");
    if (!img_settings)
        game_abort("failed to load image: settings2.png");

    /* Start Scene resources*/
    start_img_background = load_bitmap_resized("start-bg.jpg", SCREEN_W, SCREEN_H);


    player_imgs[0] = al_load_bitmap("rocket-1.png");
    player_imgs[1] = al_load_bitmap("rocket-2.png");
    player_imgs[2] = al_load_bitmap("rocket-3.png");
    player_imgs[3] = al_load_bitmap("rocket-4.png");


    start_img_enemy = al_load_bitmap("smallfighter0006.png");
    if (!start_img_enemy)
        game_abort("failed to load image: smallfighter0006.png");

    start_bgm = al_load_sample("mythica.ogg");
    if (!start_bgm)
        game_abort("failed to load audio: mythica.ogg");

    // [HACKATHON 2-5]
    // DONE: Initialize bullets.
    // 1) Search for a bullet image online and put it in your project.
    //    You can use the image we provided.
    // 2) Load it in by 'al_load_bitmap' or 'load_bitmap_resized'.
    // 3) If you use 'al_load_bitmap', don't forget to check its return value.
    // Uncomment and fill in the code below.
    img_bullet = al_load_bitmap("image12.png");
    if (!img_bullet)
        game_abort("failed to load image: image12.png");

    img_tank = al_load_bitmap("tank-1.png");
    if (!img_tank)
        game_abort("failed to load image: img_tank.png");

    img_heart_gray = al_load_bitmap("heart_gray.png");
    img_heart_red = al_load_bitmap("heart_red.png");


    enemy_bullet_tint = al_map_rgb_f(1.0, 0.8, 0.8);
    plane_hit_tint = al_map_rgba_f(0, 0, 0, 0);
    enemy_lives_tint[0] = al_map_rgba_f(1.0, 0.5, 0.5, 1.0);
    enemy_lives_tint[1] = al_map_rgba_f(1.0, 0, 0, 1.0);

    FILE *high = fopen("high.txt", "r");
    if (high != NULL) {
        fscanf(high, "%d", &highscore);
        fclose(high);
    }


    // Change to first scene.
    game_change_scene(SCENE_MENU);
}

void game_start_event_loop(void) {
    bool done = false;
    ALLEGRO_EVENT event;
    int redraws = 0;
    while (!done) {
        al_wait_for_event(game_event_queue, &event);
        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            // Event for clicking the window close button.
            game_log("Window close button clicked");
            done = true;
        } else if (event.type == ALLEGRO_EVENT_TIMER) {
            // Event for redrawing the display.
            if (event.timer.source == game_update_timer)
                // The redraw timer has ticked.
                redraws++;
        } else if (event.type == ALLEGRO_EVENT_KEY_DOWN) {
            // Event for keyboard key down.
            game_log("Key with keycode %d down", event.keyboard.keycode);
            key_state[event.keyboard.keycode] = true;
            on_key_down(event.keyboard.keycode);
        } else if (event.type == ALLEGRO_EVENT_KEY_UP) {
            // Event for keyboard key up.
            game_log("Key with keycode %d up", event.keyboard.keycode);
            key_state[event.keyboard.keycode] = false;
        } else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
            // Event for mouse key down.
            game_log("Mouse button %d down at (%d, %d)", event.mouse.button, event.mouse.x, event.mouse.y);
            mouse_state[event.mouse.button] = true;
            on_mouse_down(event.mouse.button, event.mouse.x, event.mouse.y);
        } else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP) {
            // Event for mouse key up.
            game_log("Mouse button %d up at (%d, %d)", event.mouse.button, event.mouse.x, event.mouse.y);
            mouse_state[event.mouse.button] = false;
        } else if (event.type == ALLEGRO_EVENT_MOUSE_AXES) {
            if (event.mouse.dx != 0 || event.mouse.dy != 0) {
                // Event for mouse move.
                // game_log("Mouse move to (%d, %d)", event.mouse.x, event.mouse.y);
                mouse_x = event.mouse.x;
                mouse_y = event.mouse.y;
            } else if (event.mouse.dz != 0) {
                // Event for mouse scroll.
                game_log("Mouse scroll at (%d, %d) with delta %d", event.mouse.x, event.mouse.y, event.mouse.dz);
            }
        }
        // TODO: Process more events and call callbacks by adding more
        // entries inside Scene.

        // Redraw
        if (redraws > 0 && al_is_event_queue_empty(game_event_queue)) {
            // if (redraws > 1)
            //     game_log("%d frame(s) dropped", redraws - 1);
            // Update and draw the next frame.
            game_update();
            game_draw();
            redraws = 0;
        }
    }
}

void game_update(void) {
    if (active_scene == SCENE_START) {
        plane.vx = plane.vy = 0;
        if (key_state[ALLEGRO_KEY_UP] || key_state[ALLEGRO_KEY_W])
            plane.vy -= 1;
        if (key_state[ALLEGRO_KEY_DOWN] || key_state[ALLEGRO_KEY_S])
            plane.vy += 1;
        if (key_state[ALLEGRO_KEY_LEFT] || key_state[ALLEGRO_KEY_A])
            plane.vx -= 1;
        if (key_state[ALLEGRO_KEY_RIGHT] || key_state[ALLEGRO_KEY_D])
            plane.vx += 1;
        // 0.71 is (1/sqrt(2)).
        plane.y += plane.vy * 4 * (plane.vx ? 0.71f : 1);
        plane.x += plane.vx * 4 * (plane.vy ? 0.71f : 1);
        // [HACKATHON 1-1]
        // DONE: Limit the plane's collision box inside the frame.
        //       (x, y axes can be separated.)
        // Uncomment and fill in the code below.
        if (plane.x - plane.w / 2 < 0)
            plane.x = plane.w / 2;
        else if (plane.x + plane.w / 2 > SCREEN_W)
            plane.x = SCREEN_W - plane.w / 2;
        if (plane.y - plane.h / 2< 0)
            plane.y = plane.h / 2;
        else if (plane.y + plane.h / 2> SCREEN_H)
            plane.y = SCREEN_H - plane.h / 2;
        // [HACKATHON 2-7]
        // DONE: Update bullet coordinates.
        // 1) For each bullets, if it's not hidden, update x, y
        // according to vx, vy.
        // 2) If the bullet is out of the screen, hide it.
        // Uncomment and fill in the code below.
        int i, j;
        for (i = 0; i < MAX_BULLET; i++) {
            if (bullets[i].hidden)
                continue;
            bullets[i].x += bullets[i].vx;
            bullets[i].y += bullets[i].vy;
            if (bullets[i].x < 0 || bullets[i].x >= SCREEN_W || bullets[i].y < 0 || bullets[i].y >= SCREEN_H)
                bullets[i].hidden = true;
        }


        bool no_enemy = true;
        for (i = 0; i < MAX_ENEMY; i++) {
            if (!enemies[i].hidden) {
                no_enemy = false;
                break;
            }
        }
        if (no_enemy)
            game_change_scene(SCENE_WIN);


        for (i = 0; i < MAX_ENEMY; i++) {
            if (enemies[i].hidden)
                continue;

            if (pixel_collide(&plane, &enemies[i]) && al_get_time() - last_hit >= INVINCIBLE_TIME) {
                hp -= 50;
                last_hit = al_get_time();
                if (hp <= 0) {
                    lives--;
                    hp = MAX_HP;
                    al_play_sample(lose_live, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                    if (lives < 0) {
                        game_change_scene(SCENE_LOSE);
                        return;
                    }
                }
                al_play_sample(minus_hp, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
            }

            if (i < MAX_ENEMY - HOMING_ENEMIES) {
                const int gid = i / ENEMY_PER_GROUP;
                enemies[i].y += enemygroups[gid].oscspeed * 5;
                enemies[i].x = enemies[i].orgx + sin(enemygroups[gid].offset + enemygroups[gid].y + (enemies[0].h * 1.5) * (i - gid)) * enemygroups[gid].amplitudex;
            }



            for (j = 0; j < MAX_BULLET; j++) {
                if (!bullets[j].hidden && pixel_collide(&enemies[i], &bullets[j])) {
                    bullets[j].hidden = true;
                    enemylifes[i]--;
                    score += ENEMY_HIT_SCORE;
                    if (enemylifes[i] <= 0) {
                        enemies[i].hidden = true;
                        score += ENEMY_KILL_SCORE;
                        al_play_sample(destroy, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                        break;
                    }
                    al_play_sample(hit, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                    enemies[i].tint = enemylifes[i] == 2? &enemy_lives_tint[0]: &enemy_lives_tint[1];
                }
            }

            if (enemies[i].y >= SCREEN_H) {
                enemies[i].y = -100;
                enemies[i].orgx = enemies[i].w / 2 + (float)rand() / RAND_MAX * (SCREEN_W - enemies[i].w);
            }
        }

        for (i = 0; i < MAX_ENEMY_GROUP; i++) {
            enemygroups[i].offset += enemygroups[i].oscspeed;
        }

        double now = al_get_time();

        for (i = MAX_ENEMY - HOMING_ENEMIES; i < MAX_ENEMY; i++) {
            if (enemies[i].hidden)
                continue;
            enemies[i].rotation = atan2(plane.y - enemies[i].y,plane.x - enemies[i].x) - acos(-1) / 2;
            const int id = i - (MAX_ENEMY - HOMING_ENEMIES);
            if (homing_bullets[id].hidden) {
                if (now - homing_last_shoot[id] > MAX_COOLDOWN * 6) {
                    homing_last_shoot[id] = now;
                    homing_bullets[id].hidden = false;
                    homing_bullets[id].x = enemies[i].x;
                    homing_bullets[id].y = enemies[i].y;
                    homing_bullets[id].tint = &enemy_bullet_tint;

                    homing_bullets[id].rotation = atan2(plane.y - enemies[i].y,plane.x - enemies[i].x) + acos(-1) / 2;
                }
            } else if (now - homing_last_shoot[id] < MAX_COOLDOWN * 10) {
                double theta = atan2(plane.y - homing_bullets[id].y,plane.x - homing_bullets[id].x);
                double diff = theta - (homing_bullets[id].rotation - acos(-1) / 2);
                if (diff > 0.03)
                    diff = 0.03;
                if (diff < -0.03)
                    diff = -0.03;
                homing_bullets[id].rotation += diff;
            }
            homing_bullets[id].vx = cos(homing_bullets[id].rotation - acos(-1) / 2) * 3;
            homing_bullets[id].vy = sin(homing_bullets[id].rotation - acos(-1) / 2) * 3;
        }

        for (i = 0; i < HOMING_ENEMIES; i++) {
            if (homing_bullets[i].hidden)
                continue;
            homing_bullets[i].x += homing_bullets[i].vx;
            homing_bullets[i].y += homing_bullets[i].vy;

            if (pixel_collide(&homing_bullets[i], &plane) && al_get_time() - last_hit >= INVINCIBLE_TIME) {
                homing_bullets[i].hidden = true;
                hp -= 35;
                last_hit = al_get_time();
                if (hp <= 0) {
                    lives--;
                    hp = MAX_HP;
                    al_play_sample(lose_live, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                    if (lives < 0) {
                        game_change_scene(SCENE_LOSE);
                        return;
                    }
                }
                al_play_sample(minus_hp, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
            }

            if (homing_bullets[i].x < 0 || homing_bullets[i].x >= SCREEN_W || homing_bullets[i].y < 0 || homing_bullets[i].y >= SCREEN_H)
                homing_bullets[i].hidden = true;

            for (j = 0; j < MAX_BULLET; j++) {
                if (!bullets[j].hidden && pixel_collide(&homing_bullets[i], &bullets[j])) {
                    bullets[j].hidden = true;
                    homing_bullets[i].hidden = true;
                }
            }
        }

        // [HACKATHON 2-8]
        // DONE: Shoot if key is down and cool-down is over.
        // 1) Get the time now using 'al_get_time'.
        // 2) If Space key is down in 'key_state' and the time
        //    between now and last shoot is not less that cool
        //    down time.
        // 3) Loop through the bullet array and find one that is hidden.
        //    (This part can be optimized.)
        // 4) The bullet will be found if your array is large enough.
        // 5) Set the last shoot time to now.
        // 6) Set hidden to false (recycle the bullet) and set its x, y to the
        //    front part of your plane.
        // Uncomment and fill in the code below.
        if (key_state[ALLEGRO_KEY_SPACE] && now - last_shoot_timestamp >= MAX_COOLDOWN) {
            for (i = 0; i < MAX_BULLET; i++) {
                if (bullets[i].hidden) {
                    last_shoot_timestamp = now;
                    bullets[i].hidden = false;
                    bullets[i].x = plane.x;
                    bullets[i].y = plane.y - plane.h / 2;
                    al_play_sample(fire, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                    break;
                }
            }
        }
    }
}

void game_draw(void) {
    if (active_scene == SCENE_MENU) {
        al_draw_bitmap(main_img_background, 0, 0, 0);
        al_draw_text(font_pirulen_32, al_map_rgb(255, 255, 255), SCREEN_W / 2, 30, ALLEGRO_ALIGN_CENTER, "Space Shooter");
        al_draw_text(font_pirulen_24, al_map_rgb(255, 255, 255), 20, SCREEN_H - 50, 0, "Press enter key to start");
        // [HACKATHON 3-5]
        // DONE: Draw settings images.
        // The settings icon should be located at (x, y, w, h) =
        // (SCREEN_W - 48, 10, 38, 38).
        // Change its image according to your mouse position.
        // Uncomment and fill in the code below.
        if (pnt_in_rect(mouse_x, mouse_y, SCREEN_W - 48, 10, 38, 38))
            al_draw_bitmap(img_settings2, SCREEN_W - 48, 10, 0);
        else
            al_draw_bitmap(img_settings, SCREEN_W - 48, 10, 0);
    } else if (active_scene == SCENE_START) {
        int i;
        al_draw_bitmap(start_img_background, 0, 0, 0);
        // [HACKATHON 2-9]
        // DONE: Draw all bullets in your bullet array.
        // Uncomment and fill in the code below.
        for (i = 0; i < MAX_BULLET; i++)
            draw_movable_object(bullets[i]);
        for (i = 0; i < HOMING_ENEMIES; i++)
            draw_movable_object(homing_bullets[i]);

        if ((al_get_time() - last_hit <= INVINCIBLE_TIME) && ((int)((al_get_time() - last_hit) * 7) & 1))
            plane.tint = &plane_hit_tint;
        else
            plane.tint = NULL;


        draw_movable_object(plane);

        for (i = 0; i < MAX_ENEMY; i++)
            draw_movable_object(enemies[i]);

        al_draw_textf(font_pirulen_24, al_map_rgb(50, 50, 50), 10, SCREEN_H - 35, 0,
                      "Score: %d", score);


        for (i = 1; i <= LIVES; i++) {
            if (lives >= i)
                al_draw_scaled_bitmap(img_heart_red, 0, 0, al_get_bitmap_width(img_heart_red), al_get_bitmap_height(img_heart_red),
                                      SCREEN_W - 210 + 50*i, SCREEN_H - 50, 35, 35, 0);
//            else
//                al_draw_scaled_bitmap(img_heart_gray, 0, 0, al_get_bitmap_width(img_heart_red), al_get_bitmap_height(img_heart_red),
//                                      SCREEN_W - 210 + 50*i, SCREEN_H - 50, 35, 35, 0);
        }

        al_draw_rectangle(SCREEN_W - 160, SCREEN_H - 73, SCREEN_W - 25, SCREEN_H - 55, al_map_rgb(255, 204, 68), 2);
        al_draw_filled_rectangle(SCREEN_W - 160, SCREEN_H - 73, SCREEN_W - 25 - ((1 - (double)hp / MAX_HP) * 135), SCREEN_H - 55, al_map_rgb(255, 204, 68));
        al_draw_textf(font_pirulen_small, al_map_rgb(15, 15, 15), SCREEN_W - 65, SCREEN_H - 73, ALLEGRO_ALIGN_CENTER, "%d/%d", hp, MAX_HP);

    }
    // [HACKATHON 3-9]
    // DONE: If active_scene is SCENE_SETTINGS.
    // Draw anything you want, or simply clear the display.
    else if (active_scene == SCENE_SETTINGS) {
        al_draw_bitmap(start_img_background, 0, 0, 0);
        al_draw_text(font_pirulen_32, al_map_rgb(25, 25, 25), SCREEN_W / 2, 50, ALLEGRO_ALIGN_CENTER,
                     "Choose your character");
        al_draw_text(font_pirulen_24, al_map_rgb(25, 25, 25), 20, SCREEN_H - 50, 0, "Press backspace to cancel...");

        for (int i = 0; i < 4; i++) {
            if (menu_selection == i)
                al_draw_scaled_bitmap(player_imgs[i], 0, 0, al_get_bitmap_width(player_imgs[i]), al_get_bitmap_height(player_imgs[i]),
                                      SCREEN_W / 5 * (i + 1) - 50,
                                      SCREEN_H / 2 - 50,
                                      100, 100, 0);
            else
                al_draw_scaled_bitmap(player_imgs[i], 0, 0, al_get_bitmap_width(player_imgs[i]), al_get_bitmap_height(player_imgs[i]),
                                      SCREEN_W / 5 * (i + 1) - 30,
                                      SCREEN_H / 2 - 30,
                                      60, 60, 0);

        }


    } else if (active_scene == SCENE_WIN || active_scene == SCENE_LOSE) {
        al_draw_bitmap(start_img_background, 0, 0, 0);
        al_draw_text(font_pirulen_32, al_map_rgb(25, 25, 25), SCREEN_W / 2, 50, ALLEGRO_ALIGN_CENTER,
                     active_scene == SCENE_WIN? "You WIN!": "You LOSE :(");
        al_draw_text(font_pirulen_24, al_map_rgb(25, 25, 25), 20, SCREEN_H - 50, 0, "Press enter key to continue...");
        al_draw_textf(font_pirulen_24, al_map_rgb(25, 25, 25), SCREEN_W / 2, SCREEN_H / 2 - 50, ALLEGRO_ALIGN_CENTER, "Your score is: %d!", score);
        if (new_high)
            al_draw_textf(font_pirulen_24, al_map_rgb(25, 25, 25), SCREEN_W / 2, SCREEN_H / 2 + 50, ALLEGRO_ALIGN_CENTER, "NEW HIGHSCORE!!!");
        else
            al_draw_textf(font_pirulen_24, al_map_rgb(25, 25, 25), SCREEN_W / 2, SCREEN_H / 2 + 50, ALLEGRO_ALIGN_CENTER, "HIGHSCORE: %d", highscore);
    }
    al_flip_display();
}

void game_destroy(void) {
    // Destroy everything you have created.
    // Free the memories allocated by malloc or allegro functions.
    // Destroy shared resources.
    al_destroy_font(font_pirulen_32);
    al_destroy_font(font_pirulen_24);

    /* Menu Scene resources*/
    al_destroy_bitmap(main_img_background);
    al_destroy_sample(main_bgm);
    // [HACKATHON 3-6]
    // DONE: Destroy the 2 settings images.
    // Uncomment and fill in the code below.
    al_destroy_bitmap(img_settings);
    al_destroy_bitmap(img_settings2);

    /* Start Scene resources*/
    al_destroy_bitmap(start_img_background);
    al_destroy_bitmap(start_img_plane);
    al_destroy_bitmap(start_img_enemy);
    al_destroy_sample(start_bgm);
    // [HACKATHON 2-10]
    // DONE: Destroy your bullet image.
    // Uncomment and fill in the code below.
    al_destroy_bitmap(img_bullet);

    al_destroy_timer(game_update_timer);
    al_destroy_event_queue(game_event_queue);
    al_destroy_display(game_display);
    free(mouse_state);
}

void game_change_scene(int next_scene) {
    game_log("Change scene from %d to %d", active_scene, next_scene);
    // TODO: Destroy resources initialized when creating scene.
    if (active_scene == SCENE_MENU) {
        al_stop_sample(&main_bgm_id);
        game_log("stop audio (bgm)");
    } else if (active_scene == SCENE_START) {
        al_stop_sample(&start_bgm_id);
        game_log("stop audio (bgm)");
    } else if (active_scene == SCENE_SETTINGS) {
        al_stop_sample(&menu_bgm_id);
    }
    active_scene = next_scene;
    // TODO: Allocate resources before entering scene.
    if (active_scene == SCENE_MENU) {
        if (!al_play_sample(main_bgm, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_LOOP, &main_bgm_id))
            game_abort("failed to play audio (bgm)");
    } else if (active_scene == SCENE_SETTINGS) {
        if (!al_play_sample(menu_bgm, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_LOOP, &menu_bgm_id))
            game_abort("failed to play audio (bgm)");
        menu_selection = player_style;
    } else if (active_scene == SCENE_START) {
        int i, j;
        plane.img = player_imgs[player_style];
        plane.x = 400;
        plane.y = 500;
        plane.w = al_get_bitmap_width(plane.img);
        plane.h = al_get_bitmap_height(plane.img);

        score = 0;
        hp = MAX_HP;
        lives = LIVES;
        last_hit = 0;
        for (i = 0; i < MAX_ENEMY_GROUP; i++) {
            enemygroups[i].amplitudex = 3 + (float)rand() / RAND_MAX * 1.8 * 5;
            enemygroups[i].amplitudey = 3 + (float)rand() / RAND_MAX * 1.8;
            enemygroups[i].x = enemies[0].w / 2 + enemygroups[i].amplitudex + SCREEN_W / MAX_ENEMY_GROUP * i + (float)rand() / RAND_MAX * (SCREEN_W / MAX_ENEMY_GROUP - (enemies[0].w / 2 + enemygroups[i].amplitudex) * 2);
            enemygroups[i].y = enemies[0].h + (float)rand() / RAND_MAX * SCREEN_H / 10;
            enemygroups[i].offset = (float)rand() / RAND_MAX * 5;
            //            enemygroups[i].oscspeed = 0.08 + (float)rand() / RAND_MAX * 0.5;
            enemygroups[i].oscspeed = 0.25;
            for (j = 0; j < ENEMY_PER_GROUP; j++) {
                const int id = i * ENEMY_PER_GROUP + j;
                enemies[id].img = start_img_enemy;
                enemies[id].w = al_get_bitmap_width(start_img_enemy);
                enemies[id].h = al_get_bitmap_height(start_img_enemy);
                enemies[id].x = enemygroups[i].x;
                enemies[id].orgx = enemygroups[i].x;
                enemies[id].y = enemygroups[i].y + (enemies[0].h * 1.15) * j;
                enemies[id].hidden = false;
                enemylifes[id] = ENEMY_LIFE;
                enemies[id].tint = NULL;
            }
        }

        for (i = MAX_ENEMY - HOMING_ENEMIES; i < MAX_ENEMY; i++) {
            enemies[i].img = img_tank;
            enemies[i].w = al_get_bitmap_width(img_tank);
            enemies[i].h = al_get_bitmap_height(img_tank);
            enemies[i].x = enemies[i].w / 2 + (float)rand() / RAND_MAX * (SCREEN_W - enemies[i].w);
            enemies[i].y = enemies[i].h + (float)rand() / RAND_MAX * SCREEN_H / 10;
            enemies[i].hidden = false;
            enemies[i].tint = NULL;
            enemylifes[i] = ENEMY_LIFE;
        }

        for (i = 0; i < HOMING_ENEMIES; i++) {
            homing_bullets[i].w = al_get_bitmap_width(img_bullet);
            homing_bullets[i].h = al_get_bitmap_height(img_bullet);
            homing_bullets[i].img = img_bullet;
            homing_bullets[i].hidden = true;
            homing_last_shoot[i] = al_get_time();
        }

        // [HACKATHON 2-6]
        // DONE: Initialize bullets.
        // For each bullets in array, set their w and h to the size of
        // the image, and set their img to bullet image, hidden to true,
        // (vx, vy) to (0, -3).
        // Uncomment and fill in the code below.
        for (i = 0; i < MAX_BULLET; i++) {
            bullets[i].w = al_get_bitmap_width(img_bullet);
            bullets[i].h = al_get_bitmap_height(img_bullet);
            bullets[i].img = img_bullet;
            bullets[i].vx = 0;
            bullets[i].vy = -3;
            bullets[i].hidden = true;
        }
        if (!al_play_sample(start_bgm, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_LOOP, &start_bgm_id))
            game_abort("failed to play audio (bgm)");
    } else if (active_scene == SCENE_LOSE || active_scene == SCENE_WIN) {
        al_play_sample(active_scene == SCENE_LOSE? lose_me: win_me, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
        if (score > highscore) {
            FILE *high = fopen("high.txt", "w");
            fprintf(high, "%d", score);
            fclose(high);
            highscore = score;
            new_high = true;
        }
    }
}

void on_key_down(int keycode) {
    if (active_scene == SCENE_MENU) {
        if (keycode == ALLEGRO_KEY_ENTER)
            al_play_sample(select_enter, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL), game_change_scene(SCENE_START);
    }
    // [HACKATHON 3-10]
    // DONE: If active_scene is SCENE_SETTINGS and Backspace is pressed,
    // return to SCENE_MENU.
    else if (active_scene == SCENE_SETTINGS) {
        if (keycode == ALLEGRO_KEY_BACKSPACE)
            al_play_sample(select_enter, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL), game_change_scene(SCENE_MENU);
        else if (keycode == ALLEGRO_KEY_ENTER) {
            player_style = menu_selection;
            al_play_sample(select_enter, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL), game_change_scene(SCENE_MENU);
        } else if (keycode == ALLEGRO_KEY_LEFT) {
            if (menu_selection > 0)
                menu_selection --;
        } else if (keycode == ALLEGRO_KEY_RIGHT) {
            if (menu_selection < 3)
                menu_selection++;
        }
    } else if (active_scene == SCENE_LOSE || active_scene == SCENE_WIN) {
        if (keycode == ALLEGRO_KEY_ENTER)
            al_play_sample(select_enter, 1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL), game_change_scene(SCENE_MENU);
    }
}

void on_mouse_down(int btn, int x, int y) {
    // [HACKATHON 3-8]
    // DONE: When settings clicked, switch to settings scene.
    // Uncomment and fill in the code below.
    if (active_scene == SCENE_MENU) {
        if (btn == 1) {
            if (pnt_in_rect(x, y, SCREEN_W - 48, 10, 38, 38))
                game_change_scene(SCENE_SETTINGS);
        }
    }
}

void draw_movable_object(MovableObject obj) {
    if (obj.hidden)
        return;
    if (obj.tint != NULL)
        al_draw_tinted_rotated_bitmap(obj.img, *obj.tint, obj.w / 2, obj.h / 2, obj.x, obj.y, obj.rotation, 0);
    else
        al_draw_rotated_bitmap(obj.img, obj.w / 2, obj.h / 2, obj.x, obj.y, obj.rotation, 0);
}

ALLEGRO_BITMAP *load_bitmap_resized(const char *filename, int w, int h) {
    ALLEGRO_BITMAP* loaded_bmp = al_load_bitmap(filename);
    if (!loaded_bmp)
        game_abort("failed to load image: %s", filename);
    ALLEGRO_BITMAP *resized_bmp = al_create_bitmap(w, h);
    ALLEGRO_BITMAP *prev_target = al_get_target_bitmap();

    if (!resized_bmp)
        game_abort("failed to create bitmap when creating resized image: %s", filename);
    al_set_target_bitmap(resized_bmp);
    al_draw_scaled_bitmap(loaded_bmp, 0, 0,
        al_get_bitmap_width(loaded_bmp),
        al_get_bitmap_height(loaded_bmp),
        0, 0, w, h, 0);
    al_set_target_bitmap(prev_target);
    al_destroy_bitmap(loaded_bmp);

    game_log("resized image: %s", filename);

    return resized_bmp;
}

// [HACKATHON 3-3]
// DONE: Define bool pnt_in_rect(int px, int py, int x, int y, int w, int h)
// Uncomment and fill in the code below.
bool pnt_in_rect(int px, int py, int x, int y, int w, int h) {
    return px >= x && px <= x + w && py >= y && py <= y + h;
}


// +=================================================================+
// | Code below is for debugging purpose, it's fine to remove it.    |
// | Deleting the code below and removing all calls to the functions |
// | doesn't affect the game.                                        |
// +=================================================================+

void game_abort(const char* format, ...) {
    va_list arg;
    va_start(arg, format);
    game_vlog(format, arg);
    va_end(arg);
    fprintf(stderr, "error occured, exiting after 2 secs");
    // Wait 2 secs before exiting.
    al_rest(2);
    // Force exit program.
    exit(1);
}

void game_log(const char* format, ...) {
#ifdef LOG_ENABLED
    va_list arg;
    va_start(arg, format);
    game_vlog(format, arg);
    va_end(arg);
#endif
}

void game_vlog(const char* format, va_list arg) {
#ifdef LOG_ENABLED
    static bool clear_file = true;
    // Write log to file for later debugging.
    FILE* pFile = fopen("log.txt", clear_file ? "w" : "a");
    if (pFile) {
        va_list arg2;
        va_copy(arg2, arg);
        vfprintf(pFile, format, arg2);
        va_end(arg2);
        fprintf(pFile, "\n");
        fclose(pFile);
    }
    vprintf(format, arg);
    printf("\n");
    clear_file = false;
#endif
}

int min(const float a, const float b) {
    return a < b? ceil(a): ceil(b);
}

int max(const float a, const float b) {
    return a > b? ceil(a): ceil(b);
}

unsigned char null;

bool pixel_collide(MovableObject* a, MovableObject* b) {
    int ra = max(a->w/2, a->h/2), rb = max(b->w/2, b->h/2);
    double dx = a->x - b->x, dy = a->y - b->y;
    double d = sqrt(dx * dx + dy * dy);
    if (d < ra + rb) {
        al_lock_bitmap(a->img, ALLEGRO_PIXEL_FORMAT_ANY, ALLEGRO_LOCK_READONLY);
        al_lock_bitmap(b->img, ALLEGRO_PIXEL_FORMAT_ANY, ALLEGRO_LOCK_READONLY);
        for (int x = min(a->x - a->w/2, b->x - b->w/2); x <= max(a->x + a->w/2, b->x + b->w/2); x++) {
            for (int y = min(a->y - a->h/2, b->y - b->h/2); y <= max(a->y + a->h/2, b->y + b->h/2); y++) {
                if (x >= a->x - a->w/2 && x <= a->x + a->w/2 && x >= b->x - b->w/2 && x <= b->x + b->w/2 &&
                    y >= a->y - a->h/2 && y <= a->y + a->h/2 && y >= b->y - a->h/2 && y <= b->y + b->h/2) {
                    ALLEGRO_COLOR ac = al_get_pixel(a->img, x - (a->x - a->w/2), y - (a->y - a->h/2));
                    ALLEGRO_COLOR bc = al_get_pixel(b->img, x - (b->x - b->w/2), y - (b->y - b->h/2));
                    unsigned char aa, ab;
                    al_unmap_rgba(ac, &null, &null, &null, &aa);
                    al_unmap_rgba(bc, &null, &null, &null, &ab);
                    printf("%d %d\n", aa, ab);
                    if (aa != 0 && ab != 0) {
                        al_unlock_bitmap(a->img);
                        al_unlock_bitmap(b->img);
                        return true;
                    }
                }
            }
        }
        al_unlock_bitmap(a->img);
        al_unlock_bitmap(b->img);
    }
    return false;
}
